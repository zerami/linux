@pinetech - script auto deploy environment 1.0

How to usage?
