@pinetech - script auto deploy environment 1.0
